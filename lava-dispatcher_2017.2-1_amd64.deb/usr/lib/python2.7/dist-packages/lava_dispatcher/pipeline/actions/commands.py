from lava_dispatcher.pipeline.action import Action


class CommandsAction(Action):

    name = 'commands'
